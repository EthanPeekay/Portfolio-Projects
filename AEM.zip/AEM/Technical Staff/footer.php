<div class="pull-right">
		<footer align="center">
           <p>All Right Reserved Ministry of Industry and Commerce Powered by EthanPeekay 2020</p>
        <footer>
</div>