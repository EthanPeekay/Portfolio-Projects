				
	<div class="row-fluid">
			<div class="span12"></div>
				  <div class="row-fluid">
						<div class="span10">
						<img class="index_logo" src="admin/images/mic.jpg">
						</div>	
						<div class="span12">
							<div class="motto">
							<p>WELCOME&nbsp;&nbsp;TO:</p>
							<p>MIC Admin Equipment Management System&nbsp;</p>												
							</div>											
						</div>							
				  </div>		   							
    </div>	
				