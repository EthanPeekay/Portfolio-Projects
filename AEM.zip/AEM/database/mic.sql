-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 12, 2020 at 06:07 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mic`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE IF NOT EXISTS `activity_log` (
  `activity_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(128) NOT NULL,
  PRIMARY KEY (`activity_log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`activity_log_id`, `username`, `date`, `action`) VALUES
(1, 'EthanPeekay', '2020-07-06 20:26:51', 'Edit Technical User Ethan Muchenje'),
(2, 'EthanPeekay', '2020-07-06 22:59:34', 'Add Item Laptop Lenevo'),
(3, 'EthanPeekay', '2020-07-06 23:04:10', 'Edit item info Laptop 1235456489849'),
(4, 'EthanPeekay', '2020-07-06 23:04:22', 'Edit item info Laptop 2147483647'),
(5, 'EthanPeekay', '2020-07-08 13:32:58', 'Add Employee sam,Joe,Chigwanda'),
(6, 'EthanPeekay', '2020-07-08 13:34:32', 'Add Employee Rejoice,E,Tahwa'),
(7, 'EthanPeekay', '2020-07-08 13:35:32', 'Add Employee Shawn,L,Faison'),
(8, 'EthanPeekay', '2020-07-08 13:40:32', 'Add Employee Tinomuvonga,T,Manjengwa'),
(9, 'EthanPeekay', '2020-07-08 13:43:27', 'Add Employee Sibongile,S,Manhombori'),
(10, 'EthanPeekay', '2020-07-08 13:45:26', 'Add Item monitor HP'),
(11, 'EthanPeekay', '2020-07-08 13:46:14', 'Add Item keyboard HP'),
(12, 'EthanPeekay', '2020-07-08 13:48:52', 'Add Item ADSL telephone Telone '),
(13, 'EthanPeekay', '2020-07-08 13:49:47', 'Add Item Heater Imperial'),
(14, 'EthanPeekay', '2020-07-08 13:51:21', 'Add Item desktop speakers  Panasonic'),
(15, 'EthanPeekay', '2020-07-08 13:52:52', 'Add Item TV Hisense'),
(16, 'EthanPeekay', '2020-07-08 13:56:05', 'Add Item printer LaserjetPro MFP M125a'),
(17, 'EthanPeekay', '2020-07-08 13:57:45', 'Add Item projector Lenevo'),
(23, 'EthanPeekay', '2020-07-08 14:02:54', ' 4 Return Item  8 to Department ID 19'),
(24, 'EthanPeekay', '2020-07-08 14:13:28', ' 5 Return Item  6 to Department ID 19'),
(26, 'EthanPeekay', '2020-07-08 14:14:45', ' 3 Transfer with Item name 4 to Department ID 19&nbspName&nbspICT '),
(27, 'EthanPeekay', '2020-07-08 14:14:59', ' 3 Transfer with Item name 4 to Department ID 20&nbspName&nbspAccounts'),
(28, 'EthanPeekay', '2020-07-08 14:16:28', 'Edit item info desktop speakers  778987');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id_no` varchar(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `position` varchar(128) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `employee_id_no`, `firstname`, `middlename`, `lastname`, `type`, `contact_no`, `position`) VALUES
(1, '63-8985456L', 'sam', 'Joe', 'Chigwanda', 'Contractual', '0779564231', 'HR Director'),
(2, '45-892678P-', 'Rejoice', 'E', 'Tahwa', 'Contractual', '073564891', 'Audit director'),
(3, '78-564123K-', 'Shawn', 'L', 'Faison', 'Contractual', '078245613', 'Accountant'),
(4, '22-735689J-', 'Tinomuvonga', 'T', 'Manjengwa', 'Contractual', '0772561834', 'ICT technician'),
(5, '55-8945613M', 'Sibongile', 'S', 'Manhombori', 'Regular', '0772889134', 'ICT technician');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `dep_id` int(128) NOT NULL AUTO_INCREMENT,
  `dep_name` varchar(128) NOT NULL,
  `thumbnails` varchar(128) NOT NULL,
  PRIMARY KEY (`dep_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_id`, `dep_name`, `thumbnails`) VALUES
(17, 'Human Resources', ' uploads/IMG-20191231-WA0007.jpg'),
(18, 'Procurement', 'uploads/IMG-20191230-WA0031.jpg'),
(19, 'ICT ', 'uploads/IMG-20191231-WA0005.jpg'),
(20, 'Accounts', 'uploads/IMG-20191214-WA0008.jpg'),
(21, 'Registry', 'uploads/IMG-20191231-WA0006.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_serial` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_brand` varchar(100) NOT NULL,
  `item_description` varchar(100) NOT NULL,
  `item_status` varchar(100) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`item_id`, `item_serial`, `item_name`, `item_brand`, `item_description`, `item_status`) VALUES
(1, 2147483647, 'Laptop', 'Lenevo', '<p>black</p>\r\n', 'New'),
(2, 456, 'monitor', 'HP', '<p>Black color&nbsp;</p>\r\n', 'In-Use'),
(3, 55578913, 'keyboard', 'HP', '', 'New'),
(4, 33458781, 'ADSL telephone', 'Telone ', '', 'In-Use'),
(5, 666, 'Heater', 'Imperial', 'brown heater', 'New'),
(6, 778987, 'desktop speakers ', 'Panasonic', '													grey color and includes the audio cables													', 'Defective'),
(7, 0, 'TV', 'Hisense', 'black flat screen 32" inch tv', 'In-Use'),
(8, 696955, 'printer', 'LaserjetPro MFP M125a', 'white printer has power cable flush drive, printer cable and LAN cable', 'Good condition'),
(9, 2147483647, 'projector', 'Lenevo', 'white in color\r\ncontains the bag \r\nHDMI cable\r\nVGA cable ', 'In-Use');

-- --------------------------------------------------------

--
-- Table structure for table `release_details`
--

CREATE TABLE IF NOT EXISTS `release_details` (
  `release_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `dep_id` int(128) NOT NULL,
  `item_id` int(11) NOT NULL,
  `release_id` int(11) NOT NULL,
  `release_status` varchar(128) NOT NULL,
  `remarks` varchar(128) NOT NULL,
  `date_return` datetime NOT NULL,
  PRIMARY KEY (`release_details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `release_details`
--

INSERT INTO `release_details` (`release_details_id`, `dep_id`, `item_id`, `release_id`, `release_status`, `remarks`, `date_return`) VALUES
(1, 19, 9, 1, 'pending', ' / Brand new', '0000-00-00 00:00:00'),
(2, 19, 8, 1, 'Returned', ' / Brand new', '2020-07-08 14:02:54'),
(3, 19, 6, 2, 'Returned', ' / Brand new', '2020-07-08 14:13:28'),
(4, 17, 7, 3, 'pending', ' / Brand new', '0000-00-00 00:00:00'),
(5, 20, 4, 4, 'pending', ' / Brand new', '0000-00-00 00:00:00'),
(6, 18, 2, 5, 'pending', ' / Brand new', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_release`
--

CREATE TABLE IF NOT EXISTS `tbl_release` (
  `release_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `date_borrow` datetime NOT NULL,
  PRIMARY KEY (`release_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_release`
--

INSERT INTO `tbl_release` (`release_id`, `client_id`, `date_borrow`) VALUES
(1, 4, '2020-07-08 13:58:17'),
(2, 5, '2020-07-08 13:58:43'),
(3, 1, '2020-07-08 13:59:01'),
(4, 3, '2020-07-08 13:59:43'),
(5, 2, '2020-07-08 14:14:16');

-- --------------------------------------------------------

--
-- Table structure for table `technical_user`
--

CREATE TABLE IF NOT EXISTS `technical_user` (
  `tech_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `firstname` varchar(128) NOT NULL,
  `lastname` varchar(128) NOT NULL,
  `thumbnails` varchar(128) NOT NULL,
  PRIMARY KEY (`tech_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `technical_user`
--

INSERT INTO `technical_user` (`tech_id`, `username`, `password`, `firstname`, `lastname`, `thumbnails`) VALUES
(2, 'EthanPeekay', 'user', 'Ethan', 'Muchenje', 'images/NO-IMAGE-AVAILABLE.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_history`
--

CREATE TABLE IF NOT EXISTS `transaction_history` (
  `transaction_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `client_id` int(11) NOT NULL,
  `release_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`transaction_history_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `transaction_history`
--

INSERT INTO `transaction_history` (`transaction_history_id`, `item_id`, `action`, `client_id`, `release_id`, `admin_name`, `date_added`) VALUES
(1, 9, 'Borrowing Item', 4, 1, 'EthanPeekay', '2020-07-08 13:58:17'),
(2, 8, 'Borrowing Item', 4, 1, 'EthanPeekay', '2020-07-08 13:58:17'),
(3, 6, 'Borrowing Item', 5, 2, 'EthanPeekay', '2020-07-08 13:58:43'),
(4, 7, 'Borrowing Item', 1, 3, 'EthanPeekay', '2020-07-08 13:59:01'),
(5, 4, 'Borrowing Item', 3, 4, 'EthanPeekay', '2020-07-08 13:59:43'),
(6, 2, 'Borrowing Item', 2, 5, 'EthanPeekay', '2020-07-08 14:14:16');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `adminthumbnails` varchar(128) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `adminthumbnails`) VALUES
(4, 'Ethan', 'P.', 'Muchenje', 'EthanPeekay', 'muchenje', 'uploads/IMG_0002.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE IF NOT EXISTS `user_log` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `login_date` varchar(30) NOT NULL,
  `logout_date` varchar(128) NOT NULL,
  `user_id` int(128) NOT NULL,
  `tech_id` int(128) NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`user_log_id`, `username`, `login_date`, `logout_date`, `user_id`, `tech_id`) VALUES
(1, 'EthanPeekay', '2020-07-07 08:37:53', '2020-07-10', 4, 0),
(2, 'EthanPeekay', '2020-07-07 11:10:10', '2020-07-10', 4, 0),
(3, 'EthanPeekay', '2020-07-08 13:04:18', '2020-07-10', 4, 0),
(4, 'EthanPeekay', '2020-07-08 22:18:13', '2020-07-10', 4, 0),
(5, 'EthanPeekay', '2020-07-10 06:11:22', '2020-07-10', 4, 0),
(6, 'EthanPeekay', '2020-07-10 06:12:56', '2020-07-10', 4, 0),
(7, 'EthanPeekay', '2020-07-10 06:14:37', '2020-07-10', 4, 0),
(8, 'EthanPeekay', '2020-07-10 06:15:36', '2020-07-10', 4, 0),
(9, 'EthanPeekay', '2020-07-10 06:15:50', '', 4, 0),
(10, 'EthanPeekay', '2020-07-11 20:47:47', '', 4, 0),
(11, 'EthanPeekay', '2020-07-12 18:06:18', '', 4, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
