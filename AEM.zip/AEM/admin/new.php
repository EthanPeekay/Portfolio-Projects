

<?php
$t = date("H");

if ($t<"23"){
	
	echo "Hi Ethan Have a Good day!";
}

?>

