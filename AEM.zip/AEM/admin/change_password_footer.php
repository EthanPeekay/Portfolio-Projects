<div style="text-align:center">
		<footer>
           <p>MIC Admin Equipment Management System</p>
        <footer>
</div>