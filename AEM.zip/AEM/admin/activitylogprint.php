<?php include ('include/dbcon.php');
dbcon();

?>
<html>

<head>
		<title>MIC Admin Equipment Management System</title>
		<link href="../images/mic.jpg" rel="icon" type="image">
		<style>
		
		
.container {
	width:100%;
	margin:auto;
}
		
.table {
    width: 100%;
    margin-bottom: 20px;
}	

.table-striped tbody > tr:nth-child(odd) > td,
.table-striped tbody > tr:nth-child(odd) > th {
    background-color: #f9f9f9;
}

@media print{
#print {
display:none;
}
}

#print {
	width: 90px;
    height: 30px;
    font-size: 18px;
    background: white;
    border-radius: 4px;
	margin-left:28px;
	cursor:hand;
}
		
		</style>
		
<script>
function printPage() {
    window.print();
}
</script>
		
</head>


<body>
	<div class = "container">
		<div id = "header">
		<br/>
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:left; margin-left:115px; margin-bottom:-6px; width:100px; height:100px;">
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:right; margin-right:115px; width:100px; height:100px;" >
				<center><h5 style = "font-style:Calibri"></h5>&nbsp; &nbsp;&nbsp;MINISTRY OF INDUSTRY AND COMMERCE &nbsp;	&nbsp; </center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5> &nbsp; &nbsp; MIC Admin Property Tracking Management System</center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5></center>
			<button type="submit" id="print" onclick="printPage()">Print</button>	
			<p style = "margin-left:30px; margin-top:50px; font-size:14pt; font-weight:bold;">Activity Log&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
        <div align="right">
		<b style="color:blue;">Date Prepared:</b>
		<?php include('time.php'); ?>
        </div>			
		<br/>
		<br/>
		<br/>
<form action="" method="post">
  									<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
						           
	     

										<thead>
										        <tr>					
                                                
												<th>Date</th>
												<th>System User</th>
												<th>Action</th>
									
												</tr>
												
										
										<tbody>
											
                              		<?php
										$query = mysql_query("select * from  activity_log 
										LEFT JOIN user ON activity_log.username = user.username
										order by date DESC")or die(mysql_error());
										while($row = mysql_fetch_array($query)){
										$id = $row['activity_log_id'];
										$username = $row['username'];
									?>
							
                                    <tr>
					                   

                                         <td><i class="icon-calendar"></i>&nbsp;
										 <?php  echo $row['date']; ?></td>
                                         <td>&nbsp;
										 <?php echo $row['username']; ?></td>
                                         <td><i class="icon-tasks"></i>&nbsp;
										 <?php echo $row['action']; ?></td>

                                        </tr>
                         
						                 <?php } ?>
						   
                              
										</tbody>
										</thead>
									</table>
								</form>
			</div>
	
	
	
	

	</div>
</body>


</html>