<?php include ('include/dbcon.php');
dbcon();

?>
<html>

<head>
		<title>MIC Admin Equipment Management System</title>
		<link href="../images/mic.jpg" rel="icon" type="image">
		<style>
		
		
.container {
	width:100%;
	margin:auto;
}
		
.table {
    width: 100%;
    margin-bottom: 20px;
}	

.table-striped tbody > tr:nth-child(odd) > td,
.table-striped tbody > tr:nth-child(odd) > th {
    background-color: #f9f9f9;
}

@media print{
#print {
display:none;
}
}

#print {
	width: 90px;
    height: 30px;
    font-size: 18px;
    background: white;
    border-radius: 4px;
	margin-left:28px;
	cursor:hand;
}
		
		</style>
		
<script>
function printPage() {
    window.print();
}
</script>
		
</head>


<body>
	<div class = "container">
		<div id = "header">
		<br/>
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:left; margin-left:115px; margin-bottom:-6px; width:100px; height:100px;">
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:right; margin-right:115px; width:100px; height:100px;" >
				<center><h5 style = "font-style:Calibri"></h5>&nbsp; &nbsp;&nbsp;MINISTRY OF INDUSTRY AND COMMERCE &nbsp;	&nbsp; </center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5> &nbsp; &nbsp; MIC Admin Equipment Management System</center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5></center>
			<button type="submit" id="print" onclick="printPage()">Print</button>	
			<p style = "margin-left:30px; margin-top:50px; font-size:14pt; font-weight:bold;">Property available for re-use&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
        <div align="right">
		<b style="color:blue;">Date Prepared:</b>
		<?php include('time.php'); ?>
        </div>			
		<br/>
		<br/>
		<br/>
<form action="" method="post">
  	<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
		<thead>		
		        <tr>			        
					<th class="empty"></th>
					<th>Item Name</th>
					<th>Item Description </th>
					<th>Inventory Code</th>
			        <th>Item Brand  </th>					
					<th>Item Status / Remarks </th>					
					<th>Item Realease Status  </th>
                    <th class="empty"></th>					
		    </tr>
		</thead>
<tbody>
<!-----------------------------------Content------------------------------------>
<?php
		$device_query = mysql_query("select * from item
		LEFT JOIN release_details ON item.item_id = release_details.item_id
		where remarks='/ Re-used'	
		ORDER BY item.item_id DESC")or die(mysql_error());
		while($row = mysql_fetch_array($device_query)){
		$id = $row['item_id'];	
	
		?>
										
		<tr>
		<td><?php
			   $device_query2 = mysql_query("select * from item 
			   LEFT JOIN release_details ON item.item_id=release_details.item_id
		       ORDER BY item.item_id DESC ")or die(mysql_error());
		       $dev=mysql_fetch_assoc($device_query2);
		       if($row['item_status']=='New')
		       {
			   echo '<i class="icon-check"></i><div id="hide"><strong>'.$row['item_status'].'</strong></div>';
		       }
		       else if($row['item_status']=='In-Used')
			   {
			   echo '<i class="icon-ok"></i><div id="hide"> <strong>'.$row['item_status'].'</strong></div>';
		       }
			   else if($row['item_status']=='Good condition')
			   {
			   echo '<i class="icon-ok"></i><div id="hide"><strong>'.$row['item_status'].''.$row['remarks'].'</strong></div>';
		       }
			   else
			   {
			   echo '<i class="icon-ok"></i><div id="hide"><strong>'.$row['item_status'].'</strong></div>';
		       };
			  ?>
		</td>
			<td><?php echo $row['item_name']; ?></td>
			<td><?php echo $row['item_description']; ?></td>
			<td><?php echo $row['item_serial']; ?></td>
			<td><?php echo $row['item_brand']; ?></td>					
			<td><?php
			   $device_query1 = mysql_query("select * from item
			   LEFT JOIN release_details ON item.item_id=release_details.item_id
		       ORDER BY item.item_id DESC ")or die(mysql_error());
		       $dev=mysql_fetch_assoc($device_query1);
		       if($row['item_status']=='New')
		       {
			   echo '<div class="alert alert-success"><i class="icon-check"></i><strong>'.$row['item_status'].'</strong></div>';
		       }
		       else if($row['item_status']=='In-Used')
			   {
			   echo '<div class="alert alert-warning"><i class="icon-ok"> </i><strong>'.$row['item_status'].'</strong></div>';
			   }
			   else if ($row['item_status']=='Good condition')
			   {
			   echo '<div class="alert alert-warning"><i class="icon-ok"></i><strong>'.$row['item_status'].''.$row['remarks'].'</strong></div>';
		       }
			    else
			   { 
			   echo '<div class="alert alert-danger"><i class="icon-wrench"></i><strong>'.$row['item_status'].'</strong></div>';
		       };
			   
			  ?></td>
			 <?php
		       $device_query21 = mysql_query("select * from item 
			   LEFT JOIN release_details ON item.item_id=release_details.item_id
		       ORDER BY item.item_id DESC ")or die(mysql_error());
		       $dev=mysql_fetch_assoc($device_query21);
		     ?>
			 <td><?php echo $row['release_status']; ?></td>
			<?php include('toolttip_edit_delete.php'); ?>												
			<td class="empty" width="80"><a rel="tooltip"  title="Edit item" id="e<?php echo $id; ?>" href="item_edit.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="icon-pencil"> Edit</i></a></td>
		</tr>
											
	<?php } ?>   

</tbody>
</table>
</form>	
			</div>
	
	
	
	

	</div>
</body>


</html>