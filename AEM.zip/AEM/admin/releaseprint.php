<?php include ('include/dbcon.php');
dbcon();

?>
<html>

<head>
		<title>MIC Admin Equipment Management System</title>
		<link href="../images/mic.jpg" rel="icon" type="image">
		<style>
		
		
.container {
	width:100%;
	margin:auto;
}
		
.table {
    width: 100%;
    margin-bottom: 20px;
}	

.table-striped tbody > tr:nth-child(odd) > td,
.table-striped tbody > tr:nth-child(odd) > th {
    background-color: #f9f9f9;
}

@media print{
#print {
display:none;
}
}

#print {
	width: 90px;
    height: 30px;
    font-size: 18px;
    background: white;
    border-radius: 4px;
	margin-left:28px;
	cursor:hand;
}
		
		</style>
		
<script>
function printPage() {
    window.print();
}
</script>
		
</head>


<body>
	<div class = "container">
		<div id = "header">
		<br/>
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:left; margin-left:115px; margin-bottom:-6px; width:100px; height:100px;">
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:right; margin-right:115px; width:100px; height:100px;" >
				<center><h5 style = "font-style:Calibri"></h5>&nbsp; &nbsp;&nbsp;MINISTRY OF INDUSTRY AND COMMERCE &nbsp;	&nbsp; </center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5> &nbsp; &nbsp;Admin Equipment Management System</center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5></center>
			<button type="submit" id="print" onclick="printPage()">Print</button>	
			<p style = "margin-left:30px; margin-top:50px; font-size:14pt; font-weight:bold;">Released Property List&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
        <div align="right">
		<b style="color:blue;">Date Prepared:</b>
		<?php include('time.php'); ?>
        </div>			
		<br/>
		<br/>
		<br/>
  	<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
		<thead>		
		        <tr>
				    <th class="empty"></th>
					<th>Item Name</th>
					<th>Item Description </th>
					<th>Inventory Code</th>
			        <th>Item Brand  </th>					
					<th>Item Status  </th>                  	                   					              		  
		    </tr>
		</thead>
<tbody>
<!-----------------------------------Content------------------------------------>
	
		<?php
	    $release_query = mysql_query("select * from item		                   
							where NOT EXISTS
							(select * from release_details where item.item_id = release_details.item_id)
		                     and item_status='new'							
							 ORDER BY item.item_id DESC")   or die (mysql_error());
							 while ($row= mysql_fetch_array ($release_query) ){
	                         $id=$row['item_id'];		 
		                    		
		?>
										
		<tr>
		<td width="30" class="empty">
			<input id="" class="uniform_on" name="selector[]" type="checkbox" value="<?php echo $id; ?>&nbspName&nbsp<?php echo $item_name; ?>" >
		</td>
			<td><?php echo $row['item_name']; ?></td>
			<td><?php echo $row['item_description']; ?></td>
			<td><?php echo $row['item_serial']; ?></td>
			<td><?php echo $row['item_brand']; ?></td>			
			<td><div class="alert alert-success"><i class="icon-check"></i><strong><?php echo $row['item_status']; ?></strong></div></td>		
		</tr>
											
	<?php } ?>   

</tbody>
</table>
			</div>
	
	
	
	

	</div>
</body>


</html>