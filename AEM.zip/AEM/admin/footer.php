<div class="pull-right">
		<footer align="center">
           <p style="color: white">All Rights Reserved Ministry of Industry and Commerce Powered by EthanPeekay 2020</p>
        <footer>
</div>