<?php include ('include/dbcon.php');
dbcon();

?>
<html>

<head>
		<title>MIC Admin Equipment Management System</title>
		<link href="../images/mic.jpg" rel="icon" type="image">
		<style>
		
		
.container {
	width:100%;
	margin:auto;
}
		
.table {
    width: 100%;
    margin-bottom: 20px;
}	

.table-striped tbody > tr:nth-child(odd) > td,
.table-striped tbody > tr:nth-child(odd) > th {
    background-color: #f9f9f9;
}

@media print{
#print {
display:none;
}
}

#print {
	width: 90px;
    height: 30px;
    font-size: 18px;
    background: white;
    border-radius: 4px;
	margin-left:28px;
	cursor:hand;
}
		
		</style>
		
<script>
function printPage() {
    window.print();
}
</script>
		
</head>


<body>
	<div class = "container">
		<div id = "header">
		<br/>
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:left; margin-left:115px; margin-bottom:-6px; width:100px; height:100px;">
				<img src = "images/mic.jpg" style = " margin-top:-17px; float:right; margin-right:115px; width:100px; height:100px;" >
				<center><h5 style = "font-style:Calibri"></h5>&nbsp; &nbsp;&nbsp;MINISTRY OF INDUSTRY AND COMMERCE &nbsp;	&nbsp; </center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5> &nbsp; &nbsp;Admin Equipment Management System</center>
				<center><h5 style = "font-style:Calibri; margin-top:-14px;"></h5></center>
			<button type="submit" id="print" onclick="printPage()">Print</button>	
			<p style = "margin-left:30px; margin-top:50px; font-size:14pt; font-weight:bold;">Returned Item List&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
        <div align="right">
		<b style="color:blue;">Date Prepared:</b>
		<?php include('time.php'); ?>
        </div>			
		<br/>
		<br/>
		<br/>
<form action="" method="post"><!-----------------------------------table form------------------------------------>	
  	<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
		<thead>		
		     <tr>			        
					
					<th>Employee Full Name</th>
					<th>Item Borrowed </th>
					<th>Item Code</th>
			        <th>Realease status  </th>
					<th>Item Status  </th>
					<th>Date Borrowed  </th>
					<th>Date Returned   </th>				
                    <th>Department Name </th>
					
		    </tr>
		</thead>
<tbody>
<!-----------------------------------table Content------------------------------------>									
 <?php
$returne_item = mysql_query("select * from release_details 
				                 LEFT JOIN item ON release_details.item_id = item.item_id
	                             LEFT JOIN tbl_release ON release_details.release_id=tbl_release.release_id
								 LEFT JOIN client ON tbl_release.client_id=client.client_id
								 LEFT JOIN department ON release_details.dep_id=department.dep_id								 
		                        where release_status='Returned' and  remarks=' / Brand new' ORDER BY release_details.release_details_id DESC")or die(mysql_error());
while($row = mysql_fetch_array($returne_item)){
	     $release_details_id=$row['release_details_id'];
		 $id=$row['release_id'];
		 $client_id = $row['client_id'];
		 $item_id = $row['item_id'];
         $dep_id = $row['dep_id'];		 
?>
<tr>
            <td><?php echo $row['firstname']; ?>
		    <?php echo $row['middlename']; ?>
		    <?php echo $row['lastname']; ?></td>
		    <td> <?php echo $row['item_name']; ?></td>	
			<td><?php echo $row['item_serial']; ?></td>
			<td><?php
			   $release_status_query = mysql_query("select * from release_details ")or die(mysql_error());
		       $dev=mysql_fetch_assoc($release_status_query);
		       if($row['release_status']=='pending')
		       {
			   echo '<div class="alert alert-danger"><i class="icon-ok"> </i><strong>'.$row['release_status'].'</strong></div>'; 
               }
		       else 
			   {
			  echo '<div class="alert alert-success"><i class="icon-ok"></i><strong>'.$row['release_status'].'</strong></div>';
		       };
			  ?>
			</td>
	
		<td><?php
			   $item_status_query = mysql_query("select * from item 
			   LEFT JOIN release_details ON item.item_id = release_details.item_id
			   where release_status='Returned' and  remarks=' / Brand new' ")or die(mysql_error());
		       $dev=mysql_fetch_assoc($item_status_query);
		       if($row['item_status']=='Good condition')
			   {
			   echo '<div class="alert alert-warning"><i class="icon-ok"></i><strong>'.$row['item_status'].''.$row['remarks'].'</strong></div>';
               }
		       else 
			   {
			  echo '<div class="alert alert-danger"><i class="icon-wrench"></i><strong>'.$row['item_status'].'</strong></div>';
		       };
			  ?>
		</td>
            <td><?php echo date("M d, Y H:i:s",strtotime($row['date_borrow'])); ?></td>
			<td><?php echo ($row['date_return'] == "0000-00-00 00:00:00") ? "" : date("M d, Y H:i:s",strtotime($row['date_return'])); ?></td>
			<td><div class="alert alert-success"><?php echo $row['dep_name']; ?></div></td>
			
		</tr>
											
	<?php } ?>   
</tbody>
</table>
</form>	

			</div>
	
	
	
	

	</div>
</body>


</html>