<center>
		<footer>
		<p  style="color: #fff">MINISTRY OF INDUSTRY AND COMMERCE (EthanPeekay-Muchenje) Copyright 2020</p>	
		</footer>
</center>

