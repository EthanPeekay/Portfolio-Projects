-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2020 at 10:01 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `leavedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--

CREATE TABLE IF NOT EXISTS `tblcompany` (
  `COMPID` int(11) NOT NULL AUTO_INCREMENT,
  `COMPANY` text NOT NULL,
  PRIMARY KEY (`COMPID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tblcompany`
--

INSERT INTO `tblcompany` (`COMPID`, `COMPANY`) VALUES
(2, 'Ministry Of Industry & Commerce');

-- --------------------------------------------------------

--
-- Table structure for table `tbldepts`
--

CREATE TABLE IF NOT EXISTS `tbldepts` (
  `DEPTID` int(11) NOT NULL AUTO_INCREMENT,
  `DEPTNAME` text NOT NULL,
  `DEPTSHORTNAME` varchar(30) NOT NULL,
  PRIMARY KEY (`DEPTID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbldepts`
--

INSERT INTO `tbldepts` (`DEPTID`, `DEPTNAME`, `DEPTSHORTNAME`) VALUES
(1, 'IT DEPARTMENTS', 'IT'),
(2, 'HR DEPARTMENT', 'HR'),
(3, 'REGISTRY DEPARTMENT', 'RD'),
(4, 'FINANCE & ACCOUNTING DEPARTMENT', 'FAD'),
(6, 'Procurement', 'PC');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployee`
--

CREATE TABLE IF NOT EXISTS `tblemployee` (
  `EMPID` int(11) NOT NULL AUTO_INCREMENT,
  `EMPNAME` varchar(60) NOT NULL,
  `EMPPOSITION` varchar(30) NOT NULL,
  `USERNAME` varchar(30) NOT NULL,
  `PASSWRD` text NOT NULL,
  `ACCSTATUS` varchar(5) NOT NULL DEFAULT 'NO',
  `EMPSEX` varchar(10) CHARACTER SET macce COLLATE macce_bin NOT NULL DEFAULT 'MALE',
  `COMPANY` varchar(30) NOT NULL,
  `DEPARTMENT` varchar(30) NOT NULL,
  `EMPLOYID` varchar(30) NOT NULL,
  `AVELEAVE` int(11) NOT NULL DEFAULT '18',
  PRIMARY KEY (`EMPID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tblemployee`
--

INSERT INTO `tblemployee` (`EMPID`, `EMPNAME`, `EMPPOSITION`, `USERNAME`, `PASSWRD`, `ACCSTATUS`, `EMPSEX`, `COMPANY`, `DEPARTMENT`, `EMPLOYID`, `AVELEAVE`) VALUES
(1, 'Daniel Mabika', 'Boss User', 'Danielmabika@gmail.com', '0a27e12d062ad71673d57f9c2799b207af316885', 'YES', 'MALE', 'Ministry Of Industry & Commerc', 'HR DEPARTMENT', '34', 18),
(16, 'linton', 'Normal user', 'linton@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'YES', 'MALE', 'Ministry Of Industry & Commerc', 'IT DEPARTMENTS', '34', 18),
(17, 'ethan', 'Normal user', 'ethan@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'YES', 'MALE', 'Ministry Of Industry & Commerc', 'HR DEPARTMENT', 'R176', 18),
(18, 'user1', 'Normal user', 'user1@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'YES', 'MALE', 'Ministry Of Industry & Commerc', 'Procurement', '4434', 18),
(19, 'manjengwa', 'Supervisor user', 'manjengwa@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'YES', 'MALE', 'Ministry Of Industry & Commerc', 'FINANCE & ACCOUNTING DEPARTMEN', '64532', 16),
(20, 'bvute', 'Manager user', 'bvute@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'YES', 'MALE', 'Ministry Of Industry & Commerc', 'HR DEPARTMENT', '7654345', 18),
(21, 'manhombori', 'Manager user', 'manhombori@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'YES', 'FEMALE', 'Ministry Of Industry & Commerc', 'REGISTRY DEPARTMENT', '87654', 18);

-- --------------------------------------------------------

--
-- Table structure for table `tblleave`
--

CREATE TABLE IF NOT EXISTS `tblleave` (
  `LEAVEID` int(11) NOT NULL AUTO_INCREMENT,
  `EMPLOYID` varchar(30) NOT NULL,
  `DATESTART` date NOT NULL,
  `DATEEND` date NOT NULL,
  `NODAYS` double NOT NULL,
  `SHIFTTIME` varchar(10) NOT NULL,
  `TYPEOFLEAVE` varchar(30) NOT NULL,
  `REASON` text NOT NULL,
  `LEAVESTATUS` varchar(30) NOT NULL,
  `ADMINREMARKS` text NOT NULL,
  `DATEPOSTED` date NOT NULL,
  PRIMARY KEY (`LEAVEID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tblleave`
--

INSERT INTO `tblleave` (`LEAVEID`, `EMPLOYID`, `DATESTART`, `DATEEND`, `NODAYS`, `SHIFTTIME`, `TYPEOFLEAVE`, `REASON`, `LEAVESTATUS`, `ADMINREMARKS`, `DATEPOSTED`) VALUES
(1, '10890', '2019-02-21', '2019-02-21', 1, 'All Day', 'CASUAL LEAVE', 'All day it meant one day.', 'PENDING', 'N/A', '2019-02-16'),
(2, '10890', '2019-02-23', '2019-02-23', 0.5, 'AM', 'SICK LEAVE', 'A haft of day.', 'PENDING', 'N/A', '2019-02-16'),
(3, '10890', '2019-02-26', '2019-02-28', 3, 'All Day', 'CASUAL LEAVE', 'Three Days', 'PENDING', 'N/A', '2019-02-16'),
(4, '10888', '2019-02-19', '2019-02-19', 1, 'All Day', 'SICK LEAVE', 'A day leave', 'PENDING', 'N/A', '2019-02-16'),
(5, '10888', '2019-02-20', '2019-02-20', 0.5, 'PM', 'SICK LEAVE', 'A haft of day', 'PENDING', 'N/A', '2019-02-16'),
(6, '3012', '2019-02-18', '2019-02-18', 1, 'All Day', 'SICK LEAVE', 'Same', 'APPROVED', 'N/A', '2019-02-18'),
(7, '3011', '2019-02-18', '2019-02-18', 1, 'All Day', 'SICK LEAVE', 'Lucy', 'PENDING', 'N/A', '2019-02-17'),
(8, '3012', '2019-02-19', '2019-02-19', 1, 'All Day', 'SICK LEAVE', 'Bora', 'REJECTED', 'N/A', '2019-02-18'),
(9, '10888', '2019-02-20', '2019-02-20', 1, 'All Day', 'SICK LEAVE', 'Sokmeng', 'PENDING', 'N/A', '2019-02-17'),
(10, '555', '2019-02-26', '2019-02-28', 3, 'All Day', '', 'sick leave', 'APPROVED', 'N/A', '2019-02-26'),
(11, '555', '2019-03-01', '2019-03-02', 1, 'AM', 'CASUAL LEAVE', 'casual', 'APPROVED', 'N/A', '2019-02-26'),
(12, '555', '2019-03-12', '2019-03-16', 5, 'All Day', 'CASUAL LEAVE', 'cad', 'REJECTED', 'N/A', '2019-02-26'),
(13, 'R176', '2020-06-19', '2020-06-23', 5, 'All Day', 'CASUAL LEAVE', 'sick', 'REJECTED', 'N/A', '2020-06-18'),
(14, 'R176', '2020-07-09', '2020-07-15', 7, 'All Day', 'CASUAL LEAVE', 'have family business', 'PENDING', 'N/A', '2020-07-08'),
(15, '7654345', '2020-07-09', '2020-07-17', 9, 'All Day', 'SICK LEAVE', 'sickness', 'PENDING', 'N/A', '2020-07-08'),
(16, '87654', '2020-07-10', '2020-07-21', 6, 'AM', 'CASUAL LEAVE', 'school exms', 'PENDING', 'N/A', '2020-07-08'),
(17, '64532', '2020-07-09', '2020-07-13', 2.5, 'PM', 'CASUAL LEAVE', 'family funeral', 'APPROVED', 'N/A', '2020-07-08');

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE IF NOT EXISTS `tblleavetype` (
  `LEAVTID` int(11) NOT NULL AUTO_INCREMENT,
  `LEAVETYPE` varchar(30) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  PRIMARY KEY (`LEAVTID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`LEAVTID`, `LEAVETYPE`, `DESCRIPTION`) VALUES
(1, 'SICK LEAVE', 'SICK LEAVE'),
(2, 'CASUAL LEAVE', 'CASUAL LEAVE'),
(3, 'UNPAID LEAVE', 'UNPAID LEAVE');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
